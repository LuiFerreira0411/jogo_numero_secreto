//Exercício 1
alert(`Olá ${nome}, Bem-vindo ao nosso site!`);

//Exercicio 2 
let nome = "Lua"; 
alert