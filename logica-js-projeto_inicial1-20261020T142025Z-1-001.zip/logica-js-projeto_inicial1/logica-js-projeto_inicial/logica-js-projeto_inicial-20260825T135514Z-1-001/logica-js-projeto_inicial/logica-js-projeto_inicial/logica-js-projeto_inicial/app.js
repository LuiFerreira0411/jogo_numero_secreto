alert('Bem vindo ao jogo do numero secreto')
let numeroSecreto = 5;
console.log("O numero secreto é" = numeroSecreto);
let chute = prompt("Digite sum numero de 1 a 10");

if (chute == numeroSecreto){
    alert('Você acertou! O numero secreto é ${numeroSecreto}');
}